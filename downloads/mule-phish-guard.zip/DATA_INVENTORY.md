# Data Inventory — RakshaLink Browser Extension

| Data Field | Collection Purpose | Storage Location | Retention / Shared With |
| :--- | :--- | :--- | :--- |
| **Visited Hostname & URL** | Analyzed on-device by `heuristics.js` for phishing indicators (homograph attacks, raw IPs, suspicious TLDs, lure keywords). | In-memory during active tab session. | **Zero Network Calls.** Data never leaves the browser. |
| **Pages Checked Counter** | Local counter displayed in extension popup. | Chrome `chrome.storage.local` on-device. | Saved locally until extension is uninstalled or cleared by user. |
| **Threats Blocked Counter** | Local counter displayed in extension popup. | Chrome `chrome.storage.local` on-device. | Saved locally until extension is uninstalled or cleared by user. |
| **Recent Scanned Hostnames** | Short list of recent high-risk hostnames to display in popup UI. | Chrome `chrome.storage.local` on-device. | Saved locally on-device only. |

*Note: RakshaLink runs 100% on-device. No telemetry, analytics, cookies, or remote server requests are used.*
