# Assets & Licensing — RakshaLink Browser Extension

| Asset Name | Asset Description / Path | Source / Origin | License Type |
| :--- | :--- | :--- | :--- |
| **Extension Icons** | `icons/icon16.png`, `icons/icon48.png`, `icons/icon128.png` | Project Original Assets | MIT / Open Source (Project License) |
| **Fonts** | Browser System Fonts (`system-ui`, `-apple-system`, `Segoe UI`, `Roboto`, `sans-serif`) | Local Operating System Fonts | Native OS System License |
| **Icons & Indicators** | CSS shapes and SVG mark icons (`mark`, status badges) | Project Original CSS/HTML | MIT / Open Source |
