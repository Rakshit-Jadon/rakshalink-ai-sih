# RakshaLink — Real-Time UPI/Bank Phishing & Mule-Account Guard

A two-part defensive system for the "SMS/voice link → fake bank page → UPI PIN theft → mule account" fraud chain common in India:

1. **Browser extension (included, working)** — catches the phishing-page part of the chain: spoofed domains, homograph attacks, fake KYC/refund lures, credential/PIN-entry pages.
2. **Android Guard (prototype in `../android-guard`)** — protects links opened inside Instagram and other apps with an Android `VpnService` DNS filter. It blocks suspicious domains before connection without decrypting HTTPS.

---

## Part 1 — Browser Extension (this repo)

### How it works

```
                    ┌─────────────────────────┐
 User clicks link → │ webNavigation.onBeforeNavigate │ (background.js)
                    └────────────┬────────────┘
                                 │
                     heuristics.js: evaluateUrl()
                                 │
              ┌──────────────────┼──────────────────┐
              ▼                  ▼                  ▼
            LOW               MEDIUM/HIGH
          badge = green      redirect to warning.html
          no interruption    (blocking interstitial)
```

Independently of the navigation-time score, `content.js` keeps a
`MutationObserver` running on every page. If it ever sees a password field or
a PIN/OTP-shaped input (numeric, maxlength ≤ 6, or name/placeholder matching
`pin|otp|cvv|mpin|upi`) **and** the page is not a verified brand domain, the
first focus on that field is intercepted and a modal forces the user to
consciously click through a warning before they can type. This catches
freshly-registered clone domains that score LOW on URL heuristics alone but
whose *page content* is a bank/UPI login clone.

### Detection signals (`heuristics.js`)

| Signal | Points | Rationale |
|---|---|---|
| Punycode (`xn--`) hostname | 30 | Common homograph-attack marker |
| Mixed Latin + Cyrillic/Greek | 40 | Visually identical lookalike letters |
| Brand name inside unrelated domain (`hdfcbank-kyc.xyz`) | 40 | Classic combosquatting |
| Domain within edit-distance 2 of a real brand domain | 45 | Typosquatting (`sbl.co.in` vs `sbi.co.in`) |
| Raw IP address as host | 35 | Real banks never do this |
| No HTTPS | 20 | Baseline hygiene |
| `@` in URL | 25 | Redirect-masking trick |
| Known URL shortener | 15 | Hides real destination |
| Suspicious TLD (`.tk`, `.xyz`, `.top`, …) | 10 | Disproportionately abused for phishing |
| Deep subdomain chain (≥5 labels) | 15 | e.g. `secure.login.sbi.verify-kyc.ru` |
| ≥2 urgency keywords (verify/kyc/block/refund…) | 15 | Social-engineering lure language |
| Suspicious `upi://pay` payee address | 30 | Auto-generated / non-merchant VPA |

Scores are additive, capped at 100, and banded LOW (0–24) / MEDIUM (25–54) /
HIGH (55–100). LOW pages load normally; MEDIUM and HIGH pages are blocked by
the interstitial unless the user explicitly chooses to proceed. All of this runs
**on-device with zero network calls** —
nothing about the user's browsing is sent anywhere.

### Files

```
manifest.json     MV3 manifest, permissions, content-script registration
background.js     Pre-navigation interception, badge, interstitial redirect
heuristics.js     Shared scoring engine (imported by both contexts)
content.js        In-page banner + PIN/password field guarding
overlay.css       Styles for the banner and modal (scoped, all:initial)
warning.html/.js  Full-page blocking interstitial for HIGH-risk sites
popup.html/.js/.css  Toolbar popup showing the current tab's risk breakdown
```

### Loading it locally (Chrome/Edge/Brave)

1. `chrome://extensions`
2. Enable **Developer mode** (top right)
3. **Load unpacked** → select this folder
4. Visit any page — the toolbar badge shows the live risk band; click the
   icon for the full breakdown.

### Known limitations of the browser-side approach

- **TLS certificate details** (issuer, cert-transparency age, EV status)
  aren't exposed to extension APIs in Chrome MV3, so this prototype relies on
  the browser's own padlock plus URL-structure heuristics rather than
  re-verifying the chain itself. A production build would move this check to
  a lightweight backend that fetches the cert via `openssl s_client` /
  `crypto.X509` and returns issuer + age, or use the `chrome.enterprise`
  APIs available in managed deployments.
- **Brand/allowlist coverage** is a seed list here; production needs a
  signed, remotely-updatable feed (fetched over HTTPS with certificate
  pinning) so new official domains and newly-observed phishing kits propagate
  without an extension store review cycle.
- A determined attacker who registers a domain with **zero heuristic
  signals** (clean TLD, HTTPS, no brand keyword, no urgency words) and simply
  *visually* clones a bank's login page will only be caught by the
  DOM-content field-guard, not the URL check — this is inherent to
  client-side detection and is why real deployments pair this with
  server-side threat-intel feeds (Google Safe Browsing, RBI/NPCI shared
  blocklists, MHA's National Cyber Crime Reporting Portal data).

---

## Part 2 — Android SDK (architecture, not implemented here)

This needs Android Studio / Kotlin toolchain and device-level permissions
that this sandboxed environment doesn't have, so below is the component
design a team would build from.

```
┌────────────────────────────────────────────────────────────────┐
│                      RakshaLink Android SDK                     │
│                                                                  │
│  SmsLinkExtractor           UrlHeuristicsEngine (Kotlin port     │
│  (SMS Retriever API,   →     of heuristics.js above, +           │
│   no full SMS read       ↕   TFLite phishing-URL classifier)     │
│   permission needed)         │                                   │
│                               ▼                                  │
│                        RiskScoringService
│                               │
│              ┌────────────────┼─────────────────┐
│              ▼                                    ▼
│   WarningOverlayService                 MuleAccountSignal
│   (SYSTEM_ALERT_WINDOW,                  Collector (opt-in,
│    shows a warning card                   on-device only)
│    over any app before a
│    tapped link opens in-app
│    browser / Chrome Custom Tab)
└────────────────────────────────────────────────────────────────┘
```

**SmsLinkExtractor** — uses the **SMS Retriever API** (not the broad
`READ_SMS` permission, which Play Store now restricts to default
SMS/dialer apps) to extract URLs from incoming messages that match an
app-specific hash, or integrates as a **RCS/SMS default-app plugin** for
users who opt in fully. URLs found are handed to the same scoring engine
used in the browser extension (ported to Kotlin, unit-testable against the
identical fixture set) — one shared heuristics spec, two runtimes.

**UrlHeuristicsEngine (TFLite layer)** — the rule-based score from Part 1
is the floor; a small on-device **TFLite classifier** (~200KB, character-CNN
or gradient-boosted-tree-on-features) adds a probability score trained on
features like: character n-gram entropy of the hostname, digit ratio,
hostname length vs. brand-name edit distance, path-token TF-IDF against a
phishing-kit corpus. Training/updating this model is out of scope for a
client SDK — it ships as a versioned `.tflite` asset pulled from a signed
CDN, same update path as a mobile antivirus signature file.

**WarningOverlayService** — when a flagged link is about to open (via
`Intent` interception on `ACTION_VIEW` for `http(s)`/`upi://` schemes
registered by the SDK, or an Accessibility Service the user explicitly
enables), shows a system-alert-window card *before* handing off to the
browser/UPI app — mirroring `warning.html` in Part 1. Deliberately **does
not** read or store what the user types; it only inspects the URL/intent
data being launched. This keeps the accessibility-service usage narrowly
scoped and auditable, which matters both for Play Store policy compliance
and for user trust.

**MuleAccountSignal Collector (bank/NPCI-side, not client SDK)** — mule-account
detection (sudden high-velocity many-to-one inflows followed by rapid
fan-out withdrawals, first-time payee + high amount + odd hour, device/SIM
churn across accounts) is fundamentally a **transaction-graph problem that
belongs on the NPCI/bank backend**, not the phone. The client SDK's role
here is limited to reporting a user-confirmed phishing incident (with
consent) into a shared threat-intel feed — e.g. "I was shown a fake page for
`sbi-kyc-verify.tk`, and I entered/did not enter my PIN" — which lets NPCI's
fraud-analytics pipeline correlate the SMS/link with subsequent suspicious
account activity in near-real-time, closing the loop between what a phone
detected and what NPCI's central engine acts on.

### Suggested build order for a hackathon submission

1. Ship Part 1 (this extension) as the working demo — it's fully
   self-contained and installable today.
2. For Part 2, build a thin Kotlin **stub SDK** exposing
   `RakshaLink.evaluate(url: String): RiskResult` using the ported
   heuristics only (skip TFLite for the demo — a rules engine alone is a
   legitimate, explainable MVP and judges can see the reasoning per score).
3. Wire the stub into a **demo app** that intercepts `ACTION_VIEW` intents
   and shows the same warning-card UX as `warning.html`, so both halves of
   the system visibly share one detection spec.
